package com.example.listadeitens;

import android.net.Uri;

public class MyItem {
    public Uri photo;
    public String title;
    public String description;
}
